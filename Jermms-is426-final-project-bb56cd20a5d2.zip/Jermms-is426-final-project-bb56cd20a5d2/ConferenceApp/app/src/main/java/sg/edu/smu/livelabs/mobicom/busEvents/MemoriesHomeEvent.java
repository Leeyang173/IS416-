package sg.edu.smu.livelabs.mobicom.busEvents;

import java.util.List;

import sg.edu.smu.livelabs.mobicom.net.item.MemoriesItem;


/**
 * Created by smu on 6/11/15.
 */
public class MemoriesHomeEvent {
    public boolean isNext;
    public boolean isFirst;
    public List<MemoriesItem> images;
    public boolean canUplaod;
}
