package sg.edu.smu.livelabs.mobicom.net.response;

import java.util.List;

/**
 * Created by smu on 12/11/15.
 */
public class SelfieLikersResponse {
    public String status;
    public List<SelfieUserResponse> details;
}
