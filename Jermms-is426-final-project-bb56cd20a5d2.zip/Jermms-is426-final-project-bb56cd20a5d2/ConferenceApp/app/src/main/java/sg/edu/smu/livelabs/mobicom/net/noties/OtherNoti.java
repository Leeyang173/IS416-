package sg.edu.smu.livelabs.mobicom.net.noties;

/**
 * Created by smu on 19/8/15.
 */
public class OtherNoti {
    public String content;
}
