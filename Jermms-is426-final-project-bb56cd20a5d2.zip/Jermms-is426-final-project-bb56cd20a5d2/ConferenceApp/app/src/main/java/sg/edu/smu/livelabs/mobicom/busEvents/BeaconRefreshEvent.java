package sg.edu.smu.livelabs.mobicom.busEvents;

public class BeaconRefreshEvent {
}
