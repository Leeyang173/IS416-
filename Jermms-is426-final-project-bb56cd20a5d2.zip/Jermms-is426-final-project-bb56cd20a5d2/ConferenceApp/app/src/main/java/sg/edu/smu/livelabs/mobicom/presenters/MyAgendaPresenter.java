package sg.edu.smu.livelabs.mobicom.presenters;

/**
 * Created by smu on 22/2/16.
 */
public class MyAgendaPresenter {
}
