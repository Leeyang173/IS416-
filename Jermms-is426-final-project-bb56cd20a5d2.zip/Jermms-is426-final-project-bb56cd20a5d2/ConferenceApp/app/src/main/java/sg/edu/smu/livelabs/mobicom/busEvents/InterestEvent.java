package sg.edu.smu.livelabs.mobicom.busEvents;

/**
 * Created by smu on 9/11/15.
 */
public class InterestEvent {
    public InterestEvent() {
    }
}
