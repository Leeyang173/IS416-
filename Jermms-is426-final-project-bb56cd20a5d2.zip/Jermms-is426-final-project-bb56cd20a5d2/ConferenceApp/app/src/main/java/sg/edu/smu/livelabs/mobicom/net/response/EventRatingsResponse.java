package sg.edu.smu.livelabs.mobicom.net.response;

import java.util.List;

/**
 * Created by smu on 30/4/16.
 */
public class EventRatingsResponse {
    public String status;
    public List<EventMyRatingResponse> details;
}
