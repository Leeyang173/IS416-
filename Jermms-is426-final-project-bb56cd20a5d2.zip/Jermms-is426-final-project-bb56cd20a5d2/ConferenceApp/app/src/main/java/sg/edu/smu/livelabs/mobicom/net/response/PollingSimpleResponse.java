package sg.edu.smu.livelabs.mobicom.net.response;

/**
 * Created by smu on 15/1/16.
 */
public class PollingSimpleResponse {
    public String status;
    public String details;

}
