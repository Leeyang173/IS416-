package sg.edu.smu.livelabs.mobicom.models;

/**
 * Created by smu on 2/3/16.
 */
public class AgendaComment {
    public String comment;
}
