package sg.edu.smu.livelabs.mobicom.busEvents;

/**
 * Created by smu on 1/3/16.
 */
public class AgendaReloadingEvent {
}
