package sg.edu.smu.livelabs.mobicom.busEvents;

/**
 * Created by smu on 23/4/16.
 */
public class UpdateTopicEvent {
}
