package sg.edu.smu.livelabs.mobicom.net.response;

import java.util.List;

/**
 * Created by smu on 4/4/16.
 */
public class AllAttendeesResponse {
    public String status;
    public List<AttendeeResponse> details;
}
