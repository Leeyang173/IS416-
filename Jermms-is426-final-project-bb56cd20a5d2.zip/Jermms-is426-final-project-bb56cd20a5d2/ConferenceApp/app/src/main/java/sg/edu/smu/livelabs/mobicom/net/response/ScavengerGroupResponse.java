package sg.edu.smu.livelabs.mobicom.net.response;

import java.util.List;

import sg.edu.smu.livelabs.mobicom.net.item.ScavengerGroupItem;

/**
 * Created by smu on 15/1/16.
 */
public class ScavengerGroupResponse {
    public String status;
    public List<ScavengerGroupItem> details;

}
