package sg.edu.smu.livelabs.mobicom.net.response;

/**
 * Created by smu on 11/11/15.
 */
public class SelfieSearchResponse {
    public String status;
    public SelfieSearchDetailResponse details;
}
