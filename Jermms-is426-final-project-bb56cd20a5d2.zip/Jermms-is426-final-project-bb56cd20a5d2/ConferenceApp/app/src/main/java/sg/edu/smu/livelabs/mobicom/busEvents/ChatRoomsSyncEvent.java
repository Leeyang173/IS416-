package sg.edu.smu.livelabs.mobicom.busEvents;

/**
 * Created by Aftershock PC on 1/8/2015.
 */
public class ChatRoomsSyncEvent {
    public boolean result;

    public ChatRoomsSyncEvent(boolean result) {
        this.result = result;
    }
}
