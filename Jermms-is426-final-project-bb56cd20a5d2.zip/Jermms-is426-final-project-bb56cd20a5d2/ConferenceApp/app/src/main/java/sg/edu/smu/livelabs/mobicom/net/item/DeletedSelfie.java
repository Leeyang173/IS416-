package sg.edu.smu.livelabs.mobicom.net.item;

import java.io.Serializable;

/**
 * Created by smu on 2/11/15.
 */
public class DeletedSelfie implements Serializable {
    public String id;
}
