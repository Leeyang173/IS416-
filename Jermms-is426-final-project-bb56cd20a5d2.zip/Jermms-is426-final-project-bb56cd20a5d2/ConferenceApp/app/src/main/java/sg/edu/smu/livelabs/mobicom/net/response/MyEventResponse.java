package sg.edu.smu.livelabs.mobicom.net.response;

import java.util.List;

/**
 * Created by smu on 21/3/16.
 */
public class MyEventResponse {
    public String status;
    public List<EventResponse> details; //list event Ids
}
