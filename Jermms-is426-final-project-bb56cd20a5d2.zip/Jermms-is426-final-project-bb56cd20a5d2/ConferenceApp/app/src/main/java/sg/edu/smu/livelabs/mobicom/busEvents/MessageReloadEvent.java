package sg.edu.smu.livelabs.mobicom.busEvents;

/**
 * Created by smu (Chau) on 3/7/16.
 */
public class MessageReloadEvent {
    public int focus;
    public MessageReloadEvent(int focus){
        this.focus = focus;
    }
}
