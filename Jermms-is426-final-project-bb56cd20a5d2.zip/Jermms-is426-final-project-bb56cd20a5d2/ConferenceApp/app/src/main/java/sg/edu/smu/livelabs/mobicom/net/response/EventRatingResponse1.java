package sg.edu.smu.livelabs.mobicom.net.response;

/**
 * Created by smu on 13/4/16.
 */
public class EventRatingResponse1 {
    public String status;
    public EventMyRatingResponse details;
}
