package sg.edu.smu.livelabs.mobicom.busEvents;

/**
 * Created by smu (Chau) on 24/6/16.
 */
public class RefreshTopicEvent {
    public boolean isSuccess;
    public RefreshTopicEvent(boolean isSuccess){
        this.isSuccess = isSuccess;
    }
}
