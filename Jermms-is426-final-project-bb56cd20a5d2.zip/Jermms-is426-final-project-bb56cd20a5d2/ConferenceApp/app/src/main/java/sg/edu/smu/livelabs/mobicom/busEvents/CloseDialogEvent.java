package sg.edu.smu.livelabs.mobicom.busEvents;

/**
 * Created by smu on 24/5/16.
 */
public class CloseDialogEvent {
}
