package sg.edu.smu.livelabs.mobicom.busEvents;

/**
 * Created by smu on 27/4/16.
 */
public class UpdatedAttendeesEvent {
    public boolean success;
    public UpdatedAttendeesEvent(boolean success){
        this.success = success;
    }
}
