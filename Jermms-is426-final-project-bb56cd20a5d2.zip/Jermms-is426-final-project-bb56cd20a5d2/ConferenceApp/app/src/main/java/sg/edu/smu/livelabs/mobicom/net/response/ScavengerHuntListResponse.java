package sg.edu.smu.livelabs.mobicom.net.response;

import java.util.List;

import sg.edu.smu.livelabs.mobicom.net.item.ScavengerHuntItem;

/**
 * Created by smu on 15/1/16.
 */
public class ScavengerHuntListResponse {
    public String status;
    public List<ScavengerHuntItem> details;

}
