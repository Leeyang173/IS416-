package sg.edu.smu.livelabs.mobicom.busEvents;

/**
 * Created by smu (Chau) on 15/6/16.
 */
public class NetworkEvent {
}
