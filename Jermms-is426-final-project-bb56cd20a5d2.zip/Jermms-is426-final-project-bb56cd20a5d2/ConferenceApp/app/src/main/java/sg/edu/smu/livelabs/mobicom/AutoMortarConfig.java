package sg.edu.smu.livelabs.mobicom;

import flow.path.Path;

/**
 * Created by Aftershock PC on 30/6/2015.
 */
@automortar.config.AutoMortarConfig(
        daggerServiceName = DaggerService.SERVICE_NAME,
        screenSuperclass = Path.class
)
public interface AutoMortarConfig {
}
