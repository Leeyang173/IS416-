package sg.edu.smu.livelabs.mobicom.net.response;

import java.util.List;

/**
 * Created by smu on 21/3/16.
 */
public class AllEventsResponse {
    public String status;
    public List<EventResponse> details;
}
