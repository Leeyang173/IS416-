package sg.edu.smu.livelabs.mobicom.fileupload;

/**
 * Created by Le Gia Hai on 13/5/2015.
 */
public interface FileUploadProgressListener {
    void transferred(long num);
}
