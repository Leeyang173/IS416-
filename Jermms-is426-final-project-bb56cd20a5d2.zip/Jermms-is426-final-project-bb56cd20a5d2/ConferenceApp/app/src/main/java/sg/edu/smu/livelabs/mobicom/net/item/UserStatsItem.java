package sg.edu.smu.livelabs.mobicom.net.item;

/**
 * Created by johnlee on 15/1/16.
 */
public class UserStatsItem {

    public int coolfie_image_upload_count;
    public int coolfie_image_like;
    public int event_rating;
    public int ice_breaker_friend_count;
    public int demo_open_count;
    public int beacon_rating;

    public UserStatsItem() {
    }
}
