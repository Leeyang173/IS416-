package sg.edu.smu.livelabs.mobicom.busEvents;


import sg.edu.smu.livelabs.mobicom.models.data.BeaconEntity;

/**
 * Created by smu on 7/3/16.
 */
public class BeaconRatingEvent {
    public BeaconEntity b;
}
