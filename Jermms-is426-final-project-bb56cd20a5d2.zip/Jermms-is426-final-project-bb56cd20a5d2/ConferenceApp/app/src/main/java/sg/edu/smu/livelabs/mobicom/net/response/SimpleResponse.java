package sg.edu.smu.livelabs.mobicom.net.response;

/**
 * Created by smu on 18/1/16.
 */
public class SimpleResponse {
    public String status;
    public String message;
    public String error;
    public String details;
}
