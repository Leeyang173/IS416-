package sg.edu.smu.livelabs.mobicom.net.response;

/**
 * Created by smu on 9/4/16.
 */
public class SimpleResponse2 {
    public String status;
}
