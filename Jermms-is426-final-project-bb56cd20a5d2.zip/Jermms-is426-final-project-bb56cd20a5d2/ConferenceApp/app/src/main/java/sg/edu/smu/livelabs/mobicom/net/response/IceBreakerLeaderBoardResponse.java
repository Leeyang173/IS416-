package sg.edu.smu.livelabs.mobicom.net.response;

import java.util.List;

import sg.edu.smu.livelabs.mobicom.net.item.IceBreakerLeaderBoardItem;

/**
 * Created by smu on 15/1/16.
 */
public class IceBreakerLeaderBoardResponse {
    public String status;
    public List<IceBreakerLeaderBoardItem> details;

}
