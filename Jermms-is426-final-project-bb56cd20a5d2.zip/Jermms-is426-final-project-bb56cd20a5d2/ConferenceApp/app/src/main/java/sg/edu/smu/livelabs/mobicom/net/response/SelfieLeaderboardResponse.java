package sg.edu.smu.livelabs.mobicom.net.response;

import java.util.List;

/**
 * Created by smu on 11/11/15.
 */
public class SelfieLeaderboardResponse {
    public String status;
    public List<SelfiePhotosResponse> details;
}
