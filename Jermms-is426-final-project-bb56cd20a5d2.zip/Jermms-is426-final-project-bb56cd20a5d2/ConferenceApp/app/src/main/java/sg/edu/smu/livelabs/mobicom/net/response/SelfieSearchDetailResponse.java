package sg.edu.smu.livelabs.mobicom.net.response;

import java.util.List;

import sg.edu.smu.livelabs.mobicom.net.item.Selfie;


/**
 * Created by smu on 11/11/15.
 */
public class SelfieSearchDetailResponse {
    public List<Selfie> images;
    public List<SelfieUserResponse> users;
}
