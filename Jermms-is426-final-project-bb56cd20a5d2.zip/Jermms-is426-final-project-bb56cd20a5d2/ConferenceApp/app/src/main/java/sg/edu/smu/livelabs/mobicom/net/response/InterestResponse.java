package sg.edu.smu.livelabs.mobicom.net.response;

import java.util.List;

import sg.edu.smu.livelabs.mobicom.net.item.InterestItem;

/**
 * Created by smu on 15/1/16.
 */
public class InterestResponse {
    public String status;
    public List<InterestItem> details;

}
