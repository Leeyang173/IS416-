package sg.edu.smu.livelabs.mobicom.net.response;

/**
 * Created by smu on 11/5/16.
 */
public class MacIpResponse {
    public String mac;
    public String status;
}
