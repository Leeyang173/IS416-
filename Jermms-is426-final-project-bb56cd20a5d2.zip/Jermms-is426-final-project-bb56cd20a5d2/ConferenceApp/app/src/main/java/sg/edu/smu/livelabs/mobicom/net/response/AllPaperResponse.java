package sg.edu.smu.livelabs.mobicom.net.response;

import java.util.List;

/**
 * Created by smu on 12/4/16.
 */
public class AllPaperResponse {
    public String status;
    public List<SessionPaperResponse> details;
}
