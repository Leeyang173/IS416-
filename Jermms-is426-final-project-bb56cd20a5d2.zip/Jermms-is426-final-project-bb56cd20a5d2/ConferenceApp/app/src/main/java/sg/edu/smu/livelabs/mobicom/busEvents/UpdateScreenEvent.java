package sg.edu.smu.livelabs.mobicom.busEvents;

/**
 * Created by smu on 2/9/15.
 */
public class UpdateScreenEvent {
    public Object data;
    public UpdateScreenEvent(Object data){
        this.data = data;
    }
}
