package sg.edu.smu.livelabs.mobicom.busEvents;

/**
 * Created by smu on 2/9/15.
 */
public class SaveAndChangeScreenEvent {
    public Object newScreen;
    public SaveAndChangeScreenEvent(Object newScreen){
        this.newScreen = newScreen;
    }
}
