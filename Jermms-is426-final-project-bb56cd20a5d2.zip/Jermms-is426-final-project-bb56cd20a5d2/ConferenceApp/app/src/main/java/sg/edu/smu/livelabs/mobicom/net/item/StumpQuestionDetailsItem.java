package sg.edu.smu.livelabs.mobicom.net.item;

import java.util.List;

/**
 * Created by smu on 15/1/16.
 */
public class StumpQuestionDetailsItem {
    public List<StumpQuestionItem> ques;
    public List<StumpLeaderboardItem> leaderboard;
    public int score;
}
