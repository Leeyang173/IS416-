package sg.edu.smu.livelabs.mobicom.net.response;

import java.util.List;

/**
 * Created by smu on 6/6/16.
 */
public class InboxNotificationResponse {
    public String status;
    public List<MessageResponse> details;
}
