package sg.edu.smu.livelabs.mobicom.busEvents;

/**
 * Created by smu on 20/7/15.
 */
public class UpdateBeaconPresenterEvent {
    public boolean isOn;

    public UpdateBeaconPresenterEvent(boolean isOn) {
        this.isOn = isOn;
    }
}
