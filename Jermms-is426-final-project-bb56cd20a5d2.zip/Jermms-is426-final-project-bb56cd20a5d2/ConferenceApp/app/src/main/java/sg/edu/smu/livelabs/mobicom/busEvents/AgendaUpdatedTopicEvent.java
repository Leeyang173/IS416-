package sg.edu.smu.livelabs.mobicom.busEvents;


/**
 * Created by smu on 7/3/16.
 */
public class AgendaUpdatedTopicEvent {
    public static final int ADD_OR_REMOVE_FROM_MY_AGENDA = 0;
    public static final int RATE_TOPIC = 1;
    public int type;
}
