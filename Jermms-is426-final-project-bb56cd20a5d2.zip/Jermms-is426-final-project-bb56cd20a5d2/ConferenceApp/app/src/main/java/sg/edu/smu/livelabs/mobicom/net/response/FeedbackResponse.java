package sg.edu.smu.livelabs.mobicom.net.response;

/**
 * Created by smu on 26/5/16.
 */
public class FeedbackResponse {
    public String status;
    public String details;
}
