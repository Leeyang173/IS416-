package sg.edu.smu.livelabs.mobicom.net.response;

import sg.edu.smu.livelabs.mobicom.net.item.PollingItem;

/**
 * Created by smu on 15/1/16.
 */
public class PollingResponse {
    public String status;
    public PollingItem details;

}
