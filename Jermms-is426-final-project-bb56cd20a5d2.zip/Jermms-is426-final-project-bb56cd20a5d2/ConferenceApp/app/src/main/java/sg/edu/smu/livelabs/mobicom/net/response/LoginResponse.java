package sg.edu.smu.livelabs.mobicom.net.response;

import java.util.List;

/**
 * Created by smu on 15/1/16.
 */
public class LoginResponse {
    public String status;
    public List<UserResponse> details;
}
